




select DATEPART(yyyy,soh.DueDate) as [Calendar year],st.[group] as [sales territory group],cr.Name as [Sales Territory Country],cr.Name as [Sales Territory Region],sum(soh.TotalDue) as [Sales Amount]
from Sales.SalesOrderHeader as soh
join sales.SalesTerritory as st on soh.TerritoryID=st.TerritoryID
join sales.SalesOrderDetail as sod on soh.SalesOrderID=sod.SalesOrderID
join Production.ProductCostHistory as pch on sod.ProductID=pch.ProductID
join Person.CountryRegion as cr on st.countryRegioncode=cr.CountryRegionCode
where (DATEPART(yyyy,soh.DueDate) in (2012))
group by DATEPART(yyyy,soh.DueDate),st.[group],cr.name
order by [calendar year]


select * from [dbo].[State]
select * from [dbo].[City]

select s.state_name , c.city_name from state s
join city c
on c.city_id = s.state_id








select distinct [group] from Sales.SalesTerritory
select distinct[name] from Person.CountryRegion
select distinct DATEPART(yyyy,DueDate) from Sales.SalesOrderHeader
