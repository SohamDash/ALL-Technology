select * from emp
where e_salary in (select max(e_salary) from emp)


select * from (select * from emp) a


select top 6 * from emp

select * from emp order by e_id

select * from emp order by e_id desc

select * from emp order by e_name

select * from emp order by e_name desc

select * from emp order by e_age

select * from emp order by e_salary
select e_name,e_email,e_gender,e_salary,
rank() over(partition by e_gender order by e_salary desc) as 'Salary_Rank'
from emp


select e_name,e_email,e_gender,e_salary,
dense_rank() over(order by e_salary desc) as 'Salary_Dense'
from emp

select e_name,e_email,e_gender,e_salary,
dense_rank() over(partition by e_gender order by e_salary desc) as 'Salary_Dense'
from emp


select e_name,e_email,e_gender,e_salary,
row_number() over(order by e_salary desc) as 'Salary RowNumber'
from emp

select e_name,e_email,e_gender,e_salary,
row_number() over(partition by e_gender order by e_salary desc) as 'Salary RowNumber'
from emp


select e_name,e_email,e_gender,e_salary,
ntile(3) over(order by e_salary desc) as 'Salary nTile'
from emp

