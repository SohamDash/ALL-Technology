create table filepath
(
id int identity (1,1),
name varchar(100)

)
select * from filepath

select * from sd1 join  student2 on name as 

select * from student2

select s.name , st.s_subject from sd1 s
join student st
on s.name = st.s_name
