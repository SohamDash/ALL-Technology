--Name - Soham Dash
--Emp ID - 20038

--Q1
create table employees2  (id int(8) , name varchar(30), dob date ,salary numeric (15), city varchar (12));
--Q2



	 --Q3

	 select * dob from employees where id = 'E01'and 'E03';
	 --Q4

	 select * from employees where salary = 18000 and  20000 ;
	 --Q5
	 select * from employees where city is not having 'Ahmedabad' or 'Surat';
	 --Q6
	 select * from employees where city is having 'd' in last 
	 --Q10
	 select * from employees where salary  >16000);







	 select * from employees 

