

create table employees6
(
id int, name varchar(30), dob Date ,salary numeric (15), city varchar (20)
)

insert into employees6 values (1,'Tulsi ','1982/01/26', 12000,'Ahmedabad')
 insert into employees6 values(02,'Gopi ','1983/08/15', 15000,'Anand')
  insert into employees6 values(03,'Rajshree ','1984/10/31', 20000,'Vadodara')
  insert into employees6 values (04,'Vaishali ','1985/03/23', 25000,'Surat')
    insert into employees6 values(05,'Laxmi ','1983/02/14', 18000,'Anand')
	insert into employees6(id,name,dob ,salary) values(6,'Shivali','1984/09/05',20000);


	select * from employees6


	select * from Database ExamDB
