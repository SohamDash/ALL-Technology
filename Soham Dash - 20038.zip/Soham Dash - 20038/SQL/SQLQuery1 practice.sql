create table student2(s_id int,
s_name char(15),
s_subject char(30),
s_mark numeric (3))
select * from student2

insert into student2
values (1,'Soham', 'Physics' , 75),
       (2,'Soham', 'English',50),
	   (3,'Soham', 'Science',74),
	   (4,'Krishna', 'Physics' , 80),
       (5,'Krishna', 'English',89),
	   (6,'Krishna', 'Science',87),
	   (7,'Ram', 'Physics' , 54),
       (8,'Ram', 'English',45),
	   (9,'Ram', 'Biology',55),
	   (10,'Hanzala','Physics',75),
	   (11,'Hanzala','English',80),
	   (12,'Hanzala','Science',98),
	   (13,'Tophan','Physics',50),
	   (14,'Tophan','English',97),
	   (15,'Tophan','Science',96)

select * from student2  where s_mark>=50 and s_mark<=90 and s_subject='Science'
select *,case when s_mark >90 then 'A'  when (s_mark<90 and s_mark>70)
then 'B'else 'F' end from student2  


declare @subject varchar(10)
set @subject = 'english'
declare @total int
set @total = (select sum(s_mark) from student2 where s_subject = @subject)


print @subject + 'total marks is ' + convert(varchar(10),@total)
select sum(S_MARK) from student2 where s_subject = @subject
exec @subject 





