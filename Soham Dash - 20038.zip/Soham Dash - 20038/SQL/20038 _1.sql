--Name - Soham Dash
--Emp ID - 20038

--Q1
create table student(s_id int,
s_name char(15),
s_subject char(30),
s_mark numeric (3),);
select * from student
--Q2
insert into student
values (1,'Soham', 'Physics' , 75),
       (2,'Soham', 'English',50),
	   (3,'Soham', 'Biology',74),
	   (4,'Krishna', 'Physics' , 80),
       (5,'Krishna', 'English',89),
	   (6,'Krishna', 'Biology',87),
	   (7,'Ram', 'Physics' , 54),
       (8,'Ram', 'English',45),
	   (9,'Ram', 'Biology',55)
	   select * from student
	   --Q3

	   select * from student where s_mark between 50 and 90 and s_subject = 'Science';
	   --Q4
	   select * from student where s_mark >90 print  grade =='A'
	   else where s_mark <35 print grade ='F'
	   --Q5
	   declare @subject varchar(50),@total int,@total 
	   set @ subject = 'English'
	   set @ total = <subject_name>
	   select * from total marks is <total_mark>;
	   


	    


















